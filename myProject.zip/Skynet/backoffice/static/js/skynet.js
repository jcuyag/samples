(function($) {
    $(document).ready(function() {
      $('#merchant-accounts-modal').on('hidden.bs.modal', function () {
        $(this).removeData('bs.modal');
      });

      $('#operator-modal, #request-modal, #limits-modal, #config-modal').on('hidden.bs.modal', function () {
        $(this).removeData('bs.modal');
      });

      $('#edit-merchant-account-modal, #edit-merchant-account-credentials-modal, #create-merchant-account-modal, #transaction-modal').on('hidden.bs.modal', function () {
        $(this).removeData('bs.modal');
         if ($("[name='form-changed'").val() == "true") {
            location.reload();
         }
      });

      $('#page-next').on('click', function(evt) {
        var next_page = $('#next-page').val();
        $('#id_page').val(next_page);
        $('#payment-search-form').submit();
      });

      $('#page-previous').on('click', function(evt) {
        var next_page = $('#previous-page').val();
        $('#id_page').val(next_page);
        $('#payment-search-form').submit();
      });

      $('#payment-search-form-submit').on('click', function(evt) {
        $('#id_page').val(1);
        $('#payment-search-form').submit();
      });

      $('#datetimepicker1, #datetimepicker2').datetimepicker({
        format: 'DD-MM-YYYY HH:mm'
      });

      $(".status-checkbox").bootstrapSwitch({onColor: 'success', offColor: 'danger'});

      $("table.table").tablesorter();
    });
}(jQuery))


function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function recurse( data ) {
    var json_obj = $.parseJSON(data);

    var output="<ul>";
    for (var i in json_obj)
    {
        output+="<li>" + json_obj[i][0].message + "</li>";
        var id_error = "#id_" + i;
        $(id_error).parent().addClass("has-error");
    }
    output+="</ul>";

    return( output );
}