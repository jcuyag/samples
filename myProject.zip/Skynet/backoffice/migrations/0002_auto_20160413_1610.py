# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('backoffice', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Country',
            fields=[
                ('country_id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=3)),
            ],
        ),
        migrations.CreateModel(
            name='Currency',
            fields=[
                ('currency_id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=3)),
            ],
        ),
        migrations.CreateModel(
            name='Language',
            fields=[
                ('language_id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=20)),
            ],
        ),
        migrations.AlterField(
            model_name='customer',
            name='currency',
            field=models.ForeignKey(to='backoffice.Currency'),
        ),
        migrations.AlterField(
            model_name='customerinfo',
            name='country',
            field=models.ForeignKey(to='backoffice.Country'),
        ),
        migrations.AddField(
            model_name='customerinfo',
            name='language',
            field=models.ForeignKey(default=1, to='backoffice.Language'),
            preserve_default=False,
        ),
    ]
