# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import django.core.validators


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Customer',
            fields=[
                ('customer_id', models.AutoField(serialize=False, primary_key=True)),
                ('username', models.CharField(unique=True, max_length=15)),
                ('email', models.EmailField(max_length=254)),
                ('password', models.CharField(max_length=100)),
                ('currency', models.CharField(max_length=3)),
                ('date_registered', models.DateTimeField(auto_now=True)),
                ('last_login', models.DateTimeField()),
                ('failed_login_count', models.IntegerField()),
                ('last_password_reset', models.DateTimeField()),
                ('last_login_location', models.CharField(max_length=40)),
            ],
        ),
        migrations.CreateModel(
            name='CustomerBalance',
            fields=[
                ('customer_balance_id', models.AutoField(serialize=False, primary_key=True)),
                ('balance', models.DecimalField(max_digits=20, decimal_places=4)),
                ('customer', models.ForeignKey(to='backoffice.Customer')),
            ],
        ),
        migrations.CreateModel(
            name='CustomerCategory',
            fields=[
                ('category_id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name='CustomerFinancialSettings',
            fields=[
                ('customer_financial_settings_id', models.AutoField(serialize=False, primary_key=True)),
                ('allow_deposit', models.BooleanField()),
                ('allow_withdraw', models.BooleanField()),
                ('single_transaction_limit_deposit', models.DecimalField(max_digits=20, decimal_places=4, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('daily_transaction_limit_deposit', models.DecimalField(max_digits=20, decimal_places=4, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('single_transaction_limit_withdrawal', models.DecimalField(max_digits=20, decimal_places=4, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('daily_transaction_limit_withdrawal', models.DecimalField(max_digits=20, decimal_places=4, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('customer', models.ForeignKey(to='backoffice.Customer')),
            ],
        ),
        migrations.CreateModel(
            name='CustomerInfo',
            fields=[
                ('customer_info_id', models.AutoField(serialize=False, primary_key=True)),
                ('first_name', models.CharField(max_length=40)),
                ('last_name', models.CharField(max_length=40)),
                ('address', models.CharField(max_length=100)),
                ('city', models.CharField(max_length=40)),
                ('province', models.CharField(max_length=40)),
                ('postal_code', models.CharField(max_length=10)),
                ('country', models.CharField(max_length=3)),
                ('nationality', models.CharField(max_length=3)),
                ('gender', models.CharField(max_length=1)),
                ('date_of_birth', models.DateField()),
                ('mobile_number', models.CharField(max_length=20)),
                ('im_type', models.CharField(max_length=20)),
                ('im_address', models.CharField(max_length=40)),
                ('customer', models.ForeignKey(to='backoffice.Customer')),
            ],
        ),
        migrations.CreateModel(
            name='CustomerLoginHistory',
            fields=[
                ('customer_login_history_id', models.AutoField(serialize=False, primary_key=True)),
                ('status', models.SmallIntegerField()),
                ('source', models.CharField(max_length=40)),
                ('location', models.CharField(max_length=40)),
                ('date_created', models.DateField(auto_now=True)),
                ('customer', models.ForeignKey(to='backoffice.Customer')),
            ],
        ),
        migrations.CreateModel(
            name='CustomerNotes',
            fields=[
                ('customer_notes_id', models.AutoField(serialize=False, primary_key=True)),
                ('note', models.TextField()),
                ('date_created', models.DateField(auto_now=True)),
                ('status', models.SmallIntegerField()),
                ('created_by', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='CustomerProducts',
            fields=[
                ('customer_product_id', models.AutoField(serialize=False, primary_key=True)),
                ('product_reference', models.CharField(max_length=100)),
                ('is_active', models.SmallIntegerField()),
                ('customer', models.ForeignKey(to='backoffice.Customer')),
            ],
        ),
        migrations.CreateModel(
            name='CustomerStatus',
            fields=[
                ('status_id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name='Products',
            fields=[
                ('product_id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=40)),
            ],
        ),
        migrations.AddField(
            model_name='customerproducts',
            name='product',
            field=models.ForeignKey(to='backoffice.Products'),
        ),
        migrations.AddField(
            model_name='customer',
            name='status',
            field=models.ForeignKey(to='backoffice.CustomerStatus'),
        ),
    ]
