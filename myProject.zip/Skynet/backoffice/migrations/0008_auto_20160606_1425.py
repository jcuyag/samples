# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('backoffice', '0007_auto_20160415_2351'),
    ]

    operations = [
        migrations.AlterField(
            model_name='customerstatus',
            name='name',
            field=models.CharField(unique=True, max_length=20),
        ),
    ]
