# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('backoffice', '0006_auto_20160415_1226'),
    ]

    operations = [
        migrations.CreateModel(
            name='CustomerVipLevel',
            fields=[
                ('customer_vip_level_id', models.AutoField(serialize=False, primary_key=True)),
                ('customer', models.ForeignKey(to='backoffice.Customer')),
            ],
        ),
        migrations.CreateModel(
            name='VipLevel',
            fields=[
                ('vip_level_id', models.AutoField(serialize=False, primary_key=True)),
                ('nickname', models.CharField(unique=True, max_length=40)),
                ('level', models.IntegerField()),
                ('product', models.ForeignKey(to='backoffice.Product')),
            ],
        ),
        migrations.AddField(
            model_name='customerviplevel',
            name='vip_level',
            field=models.ForeignKey(to='backoffice.VipLevel'),
        ),
    ]
