# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime
from django.utils.timezone import utc


class Migration(migrations.Migration):

    dependencies = [
        ('backoffice', '0002_auto_20160413_1610'),
    ]

    operations = [
        migrations.AddField(
            model_name='customer',
            name='reset_password_next_login',
            field=models.BooleanField(default=0),
        ),
        migrations.AddField(
            model_name='customernotes',
            name='date_updated',
            field=models.DateField(default=datetime.datetime(2016, 4, 15, 11, 34, 1, 519051, tzinfo=utc), auto_now=True),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='customer',
            name='date_registered',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='customerloginhistory',
            name='date_created',
            field=models.DateField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='customernotes',
            name='date_created',
            field=models.DateField(auto_now_add=True),
        ),
    ]
