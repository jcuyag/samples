# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import django.core.validators


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('backoffice', '0003_auto_20160415_1134'),
    ]

    operations = [
        migrations.CreateModel(
            name='CustomerFinancialSetting',
            fields=[
                ('customer_financial_settings_id', models.AutoField(serialize=False, primary_key=True)),
                ('allow_deposit', models.BooleanField()),
                ('allow_withdraw', models.BooleanField()),
                ('single_transaction_limit_deposit', models.DecimalField(max_digits=20, decimal_places=4, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('daily_transaction_limit_deposit', models.DecimalField(max_digits=20, decimal_places=4, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('single_transaction_limit_withdrawal', models.DecimalField(max_digits=20, decimal_places=4, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('daily_transaction_limit_withdrawal', models.DecimalField(max_digits=20, decimal_places=4, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('customer', models.ForeignKey(to='backoffice.Customer')),
            ],
        ),
        migrations.CreateModel(
            name='CustomerNote',
            fields=[
                ('customer_notes_id', models.AutoField(serialize=False, primary_key=True)),
                ('note', models.TextField()),
                ('date_created', models.DateField(auto_now_add=True)),
                ('date_updated', models.DateField(auto_now=True)),
                ('status', models.SmallIntegerField()),
                ('created_by', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='CustomerProduct',
            fields=[
                ('customer_product_id', models.AutoField(serialize=False, primary_key=True)),
                ('product_reference', models.CharField(max_length=100)),
                ('is_active', models.SmallIntegerField()),
                ('customer', models.ForeignKey(to='backoffice.Customer')),
            ],
        ),
        migrations.RenameModel(
            old_name='Products',
            new_name='Product',
        ),
        migrations.RemoveField(
            model_name='customerfinancialsettings',
            name='customer',
        ),
        migrations.RemoveField(
            model_name='customernotes',
            name='created_by',
        ),
        migrations.RemoveField(
            model_name='customerproducts',
            name='customer',
        ),
        migrations.RemoveField(
            model_name='customerproducts',
            name='product',
        ),
        migrations.DeleteModel(
            name='CustomerFinancialSettings',
        ),
        migrations.DeleteModel(
            name='CustomerNotes',
        ),
        migrations.DeleteModel(
            name='CustomerProducts',
        ),
        migrations.AddField(
            model_name='customerproduct',
            name='product',
            field=models.ForeignKey(to='backoffice.Product'),
        ),
    ]
