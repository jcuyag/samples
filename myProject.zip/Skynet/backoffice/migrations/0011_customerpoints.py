# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('backoffice', '0010_auto_20160613_1658'),
    ]

    operations = [
        migrations.CreateModel(
            name='CustomerPoints',
            fields=[
                ('customer_points_id', models.AutoField(serialize=False, primary_key=True)),
                ('points', models.DecimalField(max_digits=20, decimal_places=4)),
                ('customer', models.OneToOneField(to='backoffice.Customer')),
            ],
        ),
    ]
