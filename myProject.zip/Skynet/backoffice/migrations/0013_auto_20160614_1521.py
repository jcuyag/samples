# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('backoffice', '0012_auto_20160614_1027'),
    ]

    operations = [
        migrations.AddField(
            model_name='customerbalance',
            name='date_created',
            field=models.DateField(default=datetime.datetime(2016, 6, 14, 15, 20, 45, 276994), auto_now_add=True),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='customerbalance',
            name='date_updated',
            field=models.DateField(default=datetime.datetime(2016, 6, 14, 15, 20, 59, 845048), auto_now=True),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='customerpoint',
            name='date_created',
            field=models.DateField(default=datetime.datetime(2016, 6, 14, 15, 21, 19, 557082), auto_now_add=True),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='customerpoint',
            name='date_updated',
            field=models.DateField(default=datetime.datetime(2016, 6, 14, 15, 21, 33, 701711), auto_now=True),
            preserve_default=False,
        ),
    ]
