# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('backoffice', '0004_auto_20160415_1148'),
    ]

    operations = [
        migrations.CreateModel(
            name='CustomerNoteStatus',
            fields=[
                ('status_id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=20)),
            ],
        ),
        migrations.AlterField(
            model_name='customernote',
            name='status',
            field=models.ForeignKey(to='backoffice.CustomerNoteStatus'),
        ),
    ]
