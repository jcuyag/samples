# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('backoffice', '0011_customerpoints'),
    ]

    operations = [
        migrations.CreateModel(
            name='CustomerPoint',
            fields=[
                ('customer_points_id', models.AutoField(serialize=False, primary_key=True)),
                ('balance_point', models.DecimalField(max_digits=20, decimal_places=4)),
                ('customer', models.OneToOneField(to='backoffice.Customer')),
            ],
        ),
        migrations.RemoveField(
            model_name='customerpoints',
            name='customer',
        ),
        migrations.DeleteModel(
            name='CustomerPoints',
        ),
    ]
