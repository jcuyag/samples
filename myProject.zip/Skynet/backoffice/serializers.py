from rest_framework import serializers
from .models import *



class CustomerSerializer(serializers.ModelSerializer):
	currency = serializers.StringRelatedField(many=False)
	status = serializers.StringRelatedField(many=False)
	class Meta:
		model = Customer
		fields = ['username', 'currency', 'last_login', 'email',
		 		  'failed_login_count', 'last_password_reset', 'status']


class CustomerCreateSerializer(serializers.ModelSerializer):
	class Meta:
		model = Customer
		fields = ['username', 'password', 'currency', 'last_login', 'email',
		 		  'failed_login_count', 'last_password_reset', 'status']


class PasswordSerializer(serializers.ModelSerializer):
	class Meta:
		model = Customer
		fields = ['username', 'password']


class CustomerInfoSerializer(serializers.ModelSerializer):
	country = serializers.StringRelatedField(many=False)
	language = serializers.StringRelatedField(many=False)

	class Meta:
		model = CustomerInfo
		fields = '__all__'
		# fields = ['first_name', 'last_name', 'address', 'city', 
		#           'province', 'postal_code','country', 'nationality', 
		#           'language', 'gender', 'date_of_birth', 'im_type', 'im_address']


class BalanceSerializer(serializers.ModelSerializer):
	balance = serializers.FloatField()
	customer = serializers.StringRelatedField(many=False)
	class Meta:
		model = CustomerBalance
		fields = '__all__'


class TransactionHistorySerializer(serializers.ModelSerializer):
	customer = serializers.StringRelatedField(many=False)
	status = serializers.StringRelatedField(many=False)
	class Meta:
		model = CustomerTransactions
		queryset = CustomerTransactions.audit_log.all()
		fields = '__all__'
		# depth = 1
