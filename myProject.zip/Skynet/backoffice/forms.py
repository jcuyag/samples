from django import forms
from django.core.validators import MinLengthValidator

from .models import *


class CustomerSearchForm(forms.Form):
    username = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        label='Username',
        required=True,
        validators=[
            MinLengthValidator(3)
        ]
    )
    email = forms.EmailField(
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        label='Email',
        required=False
    )


class CustomerStatusForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = [
            'username',
            'status',
        ]


class CustomerNotesForm(forms.ModelForm):
    class Meta:
        model = CustomerNote
        fields = [
            'note',
            'created_by',
            'status',
        ]


class LoginForm(forms.Form):
    operator = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control input-lg'}), label='Operator', max_length=40)
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control input-lg'}), label='Username', max_length=40, required=True)
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control input-lg'}), label='Username', max_length=40, required=True)
    remember_me = forms.BooleanField(widget=forms.CheckboxInput, label='Remember Me', required=False)