import hashlib

from django.contrib import admin
from django import forms

from .models import *

admin.site.site_header = "Skynet Back Office"
admin.site.site_title = "Skynet Back Office"


class CustomerForm(forms.ModelForm):
    password = forms.CharField(required=False, widget=forms.PasswordInput)

    class Meta:
        model = Customer
        fields = '__all__'


class CustomerAdmin(admin.ModelAdmin):
    form = CustomerForm
    list_display = ('username', 'email', 'date_registered')

    def save_model(self, request, obj, form, change):
        obj.password = hashlib.sha1(form.cleaned_data['password']).hexdigest()
        obj.save()

class BalanceAdmin(admin.ModelAdmin):
	list_display = ['customer', 'balance', 'date_updated']

class PointAdmin(admin.ModelAdmin):
	list_display = ['customer', 'balance_point', 'date_updated']

class TransactionAdmin(admin.ModelAdmin):
    list_display = ['amount', 'status', 'payment_method', ]

admin.site.register(Customer, CustomerAdmin)
admin.site.register(CustomerStatus)
admin.site.register(CustomerNoteStatus)
admin.site.register(CustomerBalance, BalanceAdmin)
admin.site.register(CustomerInfo)
admin.site.register(CustomerPoint, PointAdmin)
admin.site.register(CustomerTransactions, TransactionAdmin)
admin.site.register(Operator)
admin.site.register(Employee)
admin.site.register(Currency)
admin.site.register(Country)
admin.site.register(Language)
