# from rest_framework import generics
# from rest_framework import permissions
import hashlib
import datetime
import logging

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from django.contrib.sessions.models import Session
from ...models import Customer, CustomerStatus
from ...serializers import CustomerSerializer

from util import *

logger = logging.getLogger('api')


class CustomerList(APIView):


	# def get(self, request, format=None):
	# 	check_session(request)

	# 	customers = Customer.objects.all()
	# 	serializer = CustomerSerializer(customers ,many=True)
	# 	return Response(serializer.data)

	def post(self, request, format=None):
		logger.debug('REQUEST: %s %s' %(request.user,request.data))

		# request validation, if validated set username and password
		if not validate_request_data(request, ['username', 'password']):
			return Response(response_msg(request, 4), status=status.HTTP_400_BAD_REQUEST)

		username = request.data['username']
		password = request.data['password']

		# get customer instance if exists
		customer = get_player(username)
		if not customer:
			return Response(response_msg(request, 1))

		# check if the customer session is active or suspended.
		if not check_session(request, customer):
			response_data = response_msg(request, 5)
			reason = response_data['Reason']
			response_data['Reason'] = reason %customer.username
			return Response(response_data)

		logger.debug('CUSTOMER DATA:%s %s %s %s' %(customer, 
			                         customer.failed_login_count, 
			                         customer.status,
			                         customer.last_login))

		matched = hashlib.sha1(password).hexdigest() == customer.password
		if matched:
			request.session['last_login'] = datetime.datetime.now().strftime("%I:%M:%S%p on %B %d, %Y")
			return Response(response_msg(request, 0, customer))
		return Response(response_msg(request, 2, customer))


	def get(self, request, player, token, format=None):
		"""
		Check User session
		"""

		logger.debug('%s GET: %s %s' %(__name__, player, token))
		logger.debug('%s SESSION: %s' %(__name__, request.session.session_key))

		players = get_all_logged_in_players()
		if not players.has_key(player):
			return Response(response_msg(request, 1), status=status.HTTP_500_INTERNAL_SERVER_ERROR)
		
		matched_sessions = players[player] == token
		
		if matched_sessions:
			_session = Session.objects.get(pk=token)
			# _session_time = _session.expire_date + datetime.timedelta(minutes=5)
			_session.expire_date = datetime.datetime.now() + datetime.timedelta(minutes=5)
			_session.save()
			# request.session.set_expiry(3600)
			return Response({'Result':'Success'})
		else:
			return Response(response_msg(request, 6), status=status.HTTP_500_INTERNAL_SERVER_ERROR)


	def delete(self, request, player, format=None):
		"""
		Player/Customer Log out
		"""

		logger.debug('%s SESSION: %s' %(__name__, player))

		players = get_all_logged_in_players()
		if not players.has_key(player):
			return Response(response_msg(request, 1), status=status.HTTP_500_INTERNAL_SERVER_ERROR)

		_key = players[player]
		logger.debug('%s SESSION KEY: %s' %(__name__, _key))

		_session = Session.objects.get(pk=_key)
		_session.delete()
		return Response({'Result':'Success'})

