from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from ...models import CustomerTransactions
from ...serializers import TransactionHistorySerializer

from email import JSONResponse

from util import *

logger = logging.getLogger('api')


class TransHistory(APIView):

	def post(self, request, player, format=None):
		logger.debug('%s REQUEST PLAYER: %s' %( __name__, 
												player))


		customer = get_player(player)
		if not customer:
			return Response(response_msg(request, 1))
		elif 'suspended' in customer.status.name.lower():
			response_data = response_msg(request, 5)
			response_data['Reason'] = response_data['Reason'] %customer.username 
			return Response(response_data)

		start_date = request.data['startdate']
		end_date = request.data['enddate']
		logger.debug('%s DURATION: %s - %s' %(__name__,start_date, end_date))

		customer_log = CustomerTransactions.audit_log.filter(customer=customer)
		customer_log = customer_log.filter(action_date__gte=start_date, 
										   action_date__lte=end_date)
		
		if not customer_log.exists():
			return Response({'Result':'failed', 'Reason': 'No transaction record found.'})

		# logger.debug('%s' %customer_log)

		# for record in customer_log:
		# 	serializer = TransactionHistorySerializer(record)
		def _geData(log):
			_type = {
					  'U' : 'Update record' ,
					  'I' : 'New record',
					  'D' : 'Delete record'
					}

			log_data = TransactionHistorySerializer(log).data
			log_data['transaction_type'] = _type[log.action_type]
			log_data['transaction_time'] = log.action_date
			del log_data['id']
			return log_data

		history = map(_geData, customer_log)

		return Response({'Result':'Success', 'Data':history})