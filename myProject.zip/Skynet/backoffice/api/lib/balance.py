import hashlib
import datetime
import logging

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from ...models import CustomerBalance
from ...serializers import BalanceSerializer

from util import *

logger = logging.getLogger('api')


class CustomerTrans(APIView):

	def get(self, request, player, format=None):
		"""
		Get player balance 
		"""
		logger.debug('%s REQUEST: %s' %(__name__, player))

		customer = get_player(player)
		if customer:
			try:
				balance = CustomerBalance.objects.get(customer=customer)
				points = CustomerPoint.objects.get(customer=customer)
			except CustomerBalance.DoesNotExist:
				return Response(response_msg(request, 7), status=status.HTTP_500_INTERNAL_SERVER_ERROR)
			except CustomerPoint.DoesNotExist:
				return Response(response_msg(request, 8), status=status.HTTP_500_INTERNAL_SERVER_ERROR)
		else:
			return Response(response_msg(request, 1), status=status.HTTP_500_INTERNAL_SERVER_ERROR)

		serializer = BalanceSerializer(balance)
		data = serializer.data
		data['Points'] = points.balance_point

		return Response({'Result':'Success', 'Data': data})