from django.core.mail import EmailMessage, EmailMultiAlternatives
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status
from django.http import HttpResponse
from rest_framework.renderers import JSONRenderer

from django.template.loader import get_template


from util import *


class JSONResponse(HttpResponse):
    """
    An HttpResponse that renders its content into JSON.
    """
    def __init__(self, data, **kwargs):
        content = JSONRenderer().render(data)
        kwargs['content_type'] = 'application/json'
        super(JSONResponse, self).__init__(content, **kwargs)

def send(request, player):

	customer = get_player(player)
	if not customer:
		return JSONResponse({'Result':'User not found'})

	new_password = generate_new_password()


	context = {'name' : customer.username,
			   'new_password' : new_password,
			   'product_name' : 'Skynet',
			   'sender_name' : 'Mailer'
			   }

	htmly = get_template('resetpassword.html')
	text = get_template('resetpassword.txt')

	html_content = htmly.render(context)
	text_content = text.render(context)

	subject = 'Action to Reset Password'
	from_email = 'skynettechmailer@gmail.com'
	to = [customer.email] 

	# subject, from_email, to = 'hello', 'skynettechmailer@gmail.com', 'jesse.cuyag@mwiinfo.com'
	# text_content = 'Hi %s\n Your password has been reset to %s\n Please change your password' %(customer.username, new_password)
	# html_content = '<p>Hi %s<br> Your password has been reset to <strong>%s\n</strong> Please change your password</p>' %(customer.username, new_password)
	

	msg = EmailMultiAlternatives(subject, text_content, from_email, to)
	msg.attach_alternative(html_content, "text/html")
	msg.send()
	return JSONResponse({'Result':'Success'})





