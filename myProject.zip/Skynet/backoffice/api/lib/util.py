import logging
import datetime
import string
import random

from django.contrib.sessions.models import Session
from ...models import *

SUSPENDED_TIME = 5
FAILED_LOG_IN = 5

ACTIVE = 'active'

logger = logging.getLogger('api')


def validate_new_password(new_password):
	new_password = new_password.strip()
	if len(new_password) < 8:
		return 'Password is less than 8 characters'
	elif not new_password.isalnum():
		return 'Password is not alphanumeric'

	return 'ok'

def get_session(key):
	try:
		return Session.objects.get(pk=key)
	except Session.DoesNotExist:
		return

def get_player(name):
	try:
		return Customer.objects.get(username=name)
	except Customer.DoesNotExist:
		return 

def create_update_status(status):
	try:
		return CustomerStatus.objects.get(name=status.lower())
	except CustomerStatus.DoesNotExist:
		_stat = CustomerStatus(name=status)
		_stat.save()
		return _stat

def create_get_currency(currency):
	currency = currency.upper()

	try:
		return Currency.objects.get(name=currency)
	except Currency.DoesNotExist:
		obj = Currency(name=currency)
		obj.save()
		return obj

def get_active_player(session_data):
	if session_data.has_key('user'):
		if session_data['status'] == ACTIVE and session_data['last_login'] != None:
			return session_data['user']

def get_all_logged_in_players():
	sessions = Session.objects.filter(expire_date__gte=datetime.datetime.now())

	active_users = dict()
	for session in sessions:
		data = session.get_decoded()
		active_user = get_active_player(data)
		if active_user:
			active_users[active_user] = session.session_key
	return active_users

def validate_request_data(request, data):
	for i in data:
		if not request.data.has_key(i):
			return

	return True

def check_session(request, customer_obj=None):

	# if request.session.is_empty():
	session = request.session
	session['user'] = str(request.data['username']) 
	session['last_login'] = None
	session['status'] = customer_obj.status.name
	session.set_expiry(None)
	session.save()

	logger.debug('SESSION KEY: %s' %request.session.session_key)
	if customer_obj == None:
		return
	
	# is user locked for more than 30min then activate status, otherwise status is still locked if less than 30min
	if customer_obj.status.name == 'suspended':
		time_diff = datetime.datetime.now() - customer_obj.last_login
		if time_diff.total_seconds() > SUSPENDED_TIME: # change to 1800sec for 30min locked out.
			customer_obj.status = create_update_status(ACTIVE)
			request.session['status'] = ACTIVE
			customer_obj.failed_login_count = 0
		else:
			return

	logger.debug('SESSION DATA: %s %s %s' %(session['user'], session['status'], session['last_login']))

	customer_obj.save()
	return request.session.session_key

def response_msg(request, status, customer_obj=None):
	reason 	= 	{
					0 : 'Success',
			 	 	1 : 'User cannot be found.',
			 	 	2 : 'Wrong password.',
			 	 	3 : 'Customer record is empty.',
			 	 	4 : 'Invalid request',
			 	 	5 : '%s is suspended.',
			 	 	6 : 'Invalid token.',
			 	 	7 : 'Balance not found.',
			 	 	8 : 'Points not found'
		   		}

	msg = reason[status]

	response = {'Result': 'failed', 
	        	'Reason': msg }

	if status == 0:
		customer_obj.failed_login_count = 0
		response =   {'Result': msg,
		         	  'Token':request.session.session_key}

	elif status == 2:
		time_diff = datetime.datetime.now() - customer_obj.last_login
		logger.debug('TIME DIFF: %s' %time_diff.total_seconds())
		if time_diff.total_seconds() > SUSPENDED_TIME: # change to 1800sec for 30min
			customer_obj.failed_login_count = 1
		else:
			customer_obj.failed_login_count += 1
			if customer_obj.failed_login_count == FAILED_LOG_IN:
				customer_obj.status = create_update_status('suspended')
				request.session['status'] = 'suspended'
				customer_obj.save()

	if customer_obj != None:
		customer_obj.last_login = datetime.datetime.now()
		customer_obj.save()
	
	return response


def generate_new_password(size=8, chars=string.ascii_letters + string.digits):
	return ''.join(random.choice(chars) for _ in range(size))




