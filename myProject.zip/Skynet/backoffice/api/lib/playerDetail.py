import hashlib
import datetime
import logging

from django.contrib.sessions.models import Session

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from backoffice.models import Customer, CustomerStatus, CustomerInfo
from backoffice.serializers import *

from util import *

logger = logging.getLogger('api')

class CustomerDetail(APIView):
	"""docstring for Log"""


	def get(self, request, player, format=None):
		"""
		Get player info 
		"""
		logger.debug('REQUEST: %s %s' %(player, request.data))


		try: 
			_player = get_player(player)
			player_info = CustomerInfo.objects.get(customer=_player)
		except CustomerInfo.DoesNotExist:
			 return Response(response_msg(request, 1))
		

		_customer = CustomerSerializer(_player)
		_info = CustomerInfoSerializer(player_info)

		customer_data = _customer.data
		customer_data.update(_info.data)

		return Response({'Result':'Success', 'Data': customer_data})



	def post(self, request, format=None):
		"""
		Create new player
		"""
		request.data['currency'] = create_get_currency(request.data['currency']).currency_id
		request.data['last_login'] = datetime.datetime.now()
		request.data['failed_login_count'] = 0
		request.data['last_password_reset'] = datetime.datetime.now()
		request.data['status'] = create_update_status(request.data['status']).status_id
		request.data['password'] = hashlib.sha1(request.data['password']).hexdigest()

		logger.debug('REQUEST: %s' %(request.data))

		serializers = CustomerCreateSerializer(data=request.data)
		if serializers.is_valid():
			serializers.save()
			return Response({'Result':'Success', 'Data': serializers.data})

		return Response(serializers.errors)


	def put(self, request, player, format=None):
		""" 
		Change password
		"""

		logger.debug('REQUEST: %s %s' %(player, request.data))

		# validate request data
		if validate_request_data(request, ['password', 'new password']):
			old_password = request.data['password']
			new_password = request.data['new password']
			valid_pass = validate_new_password(new_password)
			if valid_pass != 'ok':
				return Response({"Reason": valid_pass,
							     "Result":"failed"})
			del request.data['new password']
			request.data['username'] = player
			request.data['password'] = hashlib.sha1(new_password).hexdigest()
		else:
			return Response(response_msg(request, 4), status=status.HTTP_400_BAD_REQUEST)

		customer = get_player(player)
		if not customer:
			return Response(response_msg(request, 1))
		elif hashlib.sha1(old_password).hexdigest() != customer.password:
			return Response({"Reason":"Wrong password.","Result":"failed"})

		serializers = PasswordSerializer(customer, data=request.data)
		if serializers.is_valid():
			serializers.save()
			return Response({'Result':'Success'})

		return Response(serializers.errors, status=status.HTTP_400_BAD_REQUEST)
