from lib.playerList import CustomerList
from lib.playerDetail import CustomerDetail
from lib.balance import CustomerTrans
from lib.transaction import TransHistory

from lib import email as Email



class LogIn(CustomerList):
	"""
	"""

class UpdatePlayer(CustomerDetail):
	"""
	"""

class Balance(CustomerTrans):
	"""
	"""