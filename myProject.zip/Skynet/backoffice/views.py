import logging
import hashlib

from datetime import datetime

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.views.generic import TemplateView, FormView
from django.http import HttpResponse
from django.core.paginator import Paginator
from django.db import transaction
from django.utils.crypto import get_random_string

from .models import *
from .forms import *

# Logging
logger = logging.getLogger('api')


"""
Authentication Methods
"""
class LoginView(TemplateView):
    def get(self, request, *args, **kwargs):
        error_message = ""
        form = LoginForm()
        if request.user.is_authenticated():
            return redirect("/dashboard/")
        else:
            return render(request, "login.html", {"form": form, "error_message": error_message})

    def post(self, request, *args, **kwargs):
        form = LoginForm(request.POST)
        error_message = ""
        if form.is_valid():
            user = authenticate(username=form.cleaned_data["username"], password=form.cleaned_data["password"])
            if user is not None:
                if user.is_active:
                    if not form.cleaned_data["remember_me"]:
                        request.session.set_expiry(0)

                    # Add operator to session
                    if not user.is_staff:
                        current_employee = Employee.objects.filter(user=user)[:1]

                        if current_employee:
                            request.session["operator_id"] = current_employee.operator.operator_id

                            if current_employee.operator != form.cleaned_data["operator"]:
                                form = LoginForm()
                                error_message = "Login failed"
                                return render(request, "login.html", {"form": form, "error_message": error_message})
                        else:
                            form = LoginForm()
                            error_message = "Login failed"
                            return render(request, "login.html", {"form": form, "error_message": error_message})

                    else:
                        if form.cleaned_data["operator"] != "skynet":
                            form = LoginForm()
                            error_message = "Login failed"
                            return render(request, "login.html", {"form": form, "error_message": error_message})

                    login(request, user)
                    return redirect("/dashboard/")
                else:
                    form = LoginForm()
                    error_message = "User is inactive"
            else:
                form = LoginForm()
                error_message = "Login failed"
        else:
            form = LoginForm()
            error_message = "Please enter correct image characters"

        return render(request, "login.html", {"form": form, "error_message": error_message})


class LogoutView(FormView):
    def get(self, request, *args, **kwargs):
        logout(request)
        return redirect("/")


"""
Dashboard
"""
class Dashboard(TemplateView):
    def get(self, request, *args, **kwargs):
        return render(request, "dashboard.html", {
        })


"""
Customer Search
"""
class CustomerSearch(TemplateView):
    def get(self, request, *args, **kwargs):
        form = CustomerSearchForm()

        return render(
            request,
            'customer_search.html',
            {
                'form': form
            }
        )

    # TODO: Add pagination
    def post(self, request, *args, **kwargs):
        form = CustomerSearchForm(request.POST)

        if form.is_valid():
            # Build query
            filter_args = dict()

            if form.cleaned_data['username'] != '':
                filter_args['username__contains'] = form.cleaned_data['username']
            if form.cleaned_data['email'] != '':
                filter_args['email'] = form.cleaned_data['email']

            customer_object = Customer.objects.filter(**filter_args).order_by('username')

            return render(
                request,
                'customer_search_results.html',
                {
                    'form': form,
                    'Customers': customer_object
                }
            )
        else:
            return render(
                request,
                'customer_search_results.html',
                {
                    'form': form
                }
            )

"""
View Customer
"""
class ViewCustomerDetails(TemplateView):
    def get(self, request, *args, **kwargs):
        customer_id = kwargs['id']

        customer = Customer.objects.get(customer_id=customer_id)
        customer_info = CustomerInfo.objects.get(customer=customer)


        form_notes = CustomerNotesForm()

        return render(
            request,
            'customer.html',
            {
                'Customer': customer,
                'CustomerInfo': customer_info,
                'FormNotes': form_notes,
            }
        )


"""
Update Customer Status
"""
class UpdateCustomerStatus(FormView):
    def post(self, request, *args, **kwargs):
        form = CustomerStatusForm(request.POST)

        if form.is_valid():
            with transaction.atomic():
                try:
                    customer = Customer.objects.select_for_update().filter(username=form.cleaned_data['username'])
                    customer.status = CustomerStatus(int(form.cleaned_data['status']))
                    customer.save()
                    return HttpResponse(status=200)
                except Exception as e:
                    logging.error(e)
                    return HttpResponse(status=500)
        else:
            logging.error(form.errors)
            return HttpResponse(status=500)


"""
Reset Customer Password
"""
# TODO: Send emails using 3rd party SMTP provider

class ResetCustomerPassword(FormView):
    def post(self, request, *args, **kwargs):
        username = request.POST['username']
        new_password = get_random_string(10, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')

        with transaction.atomic():
            try:
                customer = Customer.objects.select_for_update().filter(username)
                customer.password = hashlib.sha1(new_password)
                customer.last_password_reset = datetime.now()
                customer.failed_login_count = 0
                customer.reset_password_next_login = True
                customer.save()
                return HttpResponse(status=200)
            except Exception as e:
                logging.error(e)
                return HttpResponse(status=500)


"""
Add/Update Customer Notes
"""
class AddUpdatedCustomerNotes(FormView):
    def post(self, request, *args, **kwargs):
        customer_notes_id = request.POST['customer_notes_id']

        if customer_notes_id == 0:
            try:
                customer_note = CustomerNote(
                    note=request.POST['note'],
                    created_by=request.user,
                    status=CustomerNoteStatus(1)
                )
                customer_note.save()
                return HttpResponse(status=200)
            except Exception as e:
                logging.error(e)
                return HttpResponse(status=500)
        else:
            try:
                customer_note = CustomerNote.objects.get(customer_notes_id=customer_notes_id)
                customer_note.note = request.POST['note']
                customer_note.status = request.POST['status']
                customer_note.save()
                return HttpResponse(status=200)
            except Exception as e:
                logging.error(e)
                return HttpResponse(status=500)


"""
Messaging Methods
"""
class Messages(TemplateView):
    def get(self, request, *args, **kwargs):
        return render(request, "messages.html")