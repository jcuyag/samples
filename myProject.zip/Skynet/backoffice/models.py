from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator

from auditlog.registry import auditlog

from audit_log.models import AuthStampedModel
from audit_log.models.managers import AuditLog
from audit_log.models.fields import LastUserField,\
                                    LastSessionKeyField,\
                                    CreatingUserField,\
                                    CreatingSessionKeyField


class Currency(models.Model):
    currency_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=3)

    def __unicode__(self):
        return self.name


class Country(models.Model):
    country_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=3)

    def __unicode__(self):
        return self.name


class Language(models.Model):
    language_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)

    def __unicode__(self):
        return self.name


class CustomerStatus(models.Model):
    status_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20, unique=True)

    def __unicode__(self):
        return self.name


class CustomerNoteStatus(models.Model):
    status_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)

    def __unicode__(self):
        return self.name


class CustomerCategory(models.Model):
    category_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)

    def __unicode__(self):
        return self.name


class Customer(models.Model):
    customer_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=15, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    status = models.ForeignKey(CustomerStatus)
    currency = models.ForeignKey(Currency)
    date_registered = models.DateTimeField(auto_now_add=True)
    last_login = models.DateTimeField()
    failed_login_count = models.IntegerField()
    last_password_reset = models.DateTimeField()
    last_login_location = models.CharField(max_length=40)
    reset_password_next_login = models.BooleanField(default=0)

    def __unicode__(self):
        return self.username
          

class CustomerInfo(models.Model):
    customer_info_id = models.AutoField(primary_key=True)
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=40)
    last_name = models.CharField(max_length=40)
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=40)
    province = models.CharField(max_length=40)
    postal_code = models.CharField(max_length=10)
    country = models.ForeignKey(Country)
    nationality = models.CharField(max_length=3)
    language = models.ForeignKey(Language)
    gender = models.CharField(max_length=1)
    date_of_birth = models.DateField()
    mobile_number = models.CharField(max_length=20)
    im_type = models.CharField(max_length=20)
    im_address = models.CharField(max_length=40)

    def __unicode__(self):
        return self.customer.username


class CustomerNote(models.Model):
    customer_notes_id = models.AutoField(primary_key=True)
    note = models.TextField()
    date_created = models.DateField(auto_now_add=True)
    date_updated = models.DateField(auto_now=True)
    created_by = models.ForeignKey(User)
    status = models.ForeignKey(CustomerNoteStatus)


class CustomerLoginHistory(models.Model):
    customer_login_history_id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(Customer)
    status = models.SmallIntegerField()
    source = models.CharField(max_length=40)
    location = models.CharField(max_length=40)
    date_created = models.DateField(auto_now_add=True)


class CustomerFinancialSetting(models.Model):
    customer_financial_settings_id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(Customer)
    allow_deposit = models.BooleanField()
    allow_withdraw = models.BooleanField()
    single_transaction_limit_deposit = models.DecimalField(
        max_digits=20,
        decimal_places=4,
        validators=[MinValueValidator(0.01)]
    )
    daily_transaction_limit_deposit = models.DecimalField(
        max_digits=20,
        decimal_places=4,
        validators=[MinValueValidator(0.01)]
    )
    single_transaction_limit_withdrawal = models.DecimalField(
        max_digits=20,
        decimal_places=4,
        validators=[MinValueValidator(0.01)]
    )
    daily_transaction_limit_withdrawal = models.DecimalField(
        max_digits=20,
        decimal_places=4,
        validators=[MinValueValidator(0.01)]
    )


class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=40)

    def __unicode__(self):
        return self.name


class CustomerProduct(models.Model):
    customer_product_id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(Customer)
    product = models.ForeignKey(Product)
    product_reference = models.CharField(max_length=100)
    is_active = models.SmallIntegerField()


class CustomerBalance(models.Model):
    customer_balance_id = models.AutoField(primary_key=True)
    customer = models.OneToOneField(Customer)
    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)
    balance = models.DecimalField(
        max_digits=20,
        decimal_places=4
    )

    def __unicode__(self):
        return self.customer.username

class CustomerPoint(models.Model):
    customer_points_id = models.AutoField(primary_key=True)
    customer = models.OneToOneField(Customer)
    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)
    balance_point = models.DecimalField(
        max_digits=20,
        decimal_places=4
    )

    def __unicode__(self):
        return self.customer.username


class CustomerTransactions(models.Model):
    # created_by = CreatingUserField(related_name = "created_categories")
    # created_with_session_key = CreatingSessionKeyField()
    customer = models.OneToOneField(Customer)
    status = models.ForeignKey(CustomerNoteStatus)
    payment_method = models.CharField(max_length=40)
    amount = models.DecimalField(max_digits=20,
                                 decimal_places=4)

    audit_log = AuditLog()

    def __unicode__(self):
        return self.customer.username

class Operator(models.Model):
    operator_id = models.AutoField(primary_key=True)
    operator_code = models.CharField(max_length=40, unique=True, null=True)
    operator_name = models.CharField(max_length=40, unique=True)
    contact_person = models.CharField(max_length=200, unique=True, null=True)
    contact_email = models.EmailField()
    is_active = models.BooleanField(default=1)  # 1 = active; 0 = inactive;

    def __unicode__(self):
        return self.operator_name


class Employee(models.Model):
    user = models.OneToOneField(User)
    operator = models.ForeignKey(Operator)

    def __unicode__(self):
        return self.user.username


class VipLevel(models.Model):
    vip_level_id = models.AutoField(primary_key=True)
    nickname = models.CharField(max_length=40, unique=True)
    level = models.IntegerField()
    product = models.ForeignKey(Product)


class CustomerVipLevel(models.Model):
    customer_vip_level_id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(Customer)
    vip_level = models.ForeignKey(VipLevel)


auditlog.register(Currency)
auditlog.register(Customer) 
auditlog.register(CustomerStatus)
auditlog.register(CustomerInfo)
auditlog.register(CustomerBalance)
auditlog.register(CustomerPoint)